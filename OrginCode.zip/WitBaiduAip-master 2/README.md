WitBaiduAip
===
Unity3d中的百度语音识别和语音合成Restful接口的封装，适用于全平台

本工程基于Unity 2017.3.0f3 (Scripting Runtime Version: .Net 3.5)

工程中包含了2个Demo场景
- 语音识别，见Assets\WitBaiduAip\Examples\Asr.unity
- 语音合成，见Assets\WitBaiduAip\Examples\Tts.unity

更新日志
---
- 2018年8月21日 百度API支持了wav格式，移除第三方插件，直接使用原生API
- 2018年3月29日 加入了UWP平台支持，移除naudio，使用mp3sharp  
- 2018年3月28日 加入了平台判断，windows平台使用naudio，android和ios可直接使用mp3  
- 2018年1月14日 加入了token获取状态的判断

欢迎关注“洪流学堂”微信公众号
---
洪流学堂，让你快人几步。  
![](https://raw.githubusercontent.com/zhenghongzhi/WitBaiduAip/master/%E5%85%B3%E6%B3%A8%E2%80%9C%E6%B4%AA%E6%B5%81%E5%AD%A6%E5%A0%82%E2%80%9D%E5%85%AC%E4%BC%97%E5%8F%B7%EF%BC%8C%E8%AE%A9%E4%BD%A0%E5%BF%AB%E4%BA%BA%E5%87%A0%E6%AD%A5.jpg)  
